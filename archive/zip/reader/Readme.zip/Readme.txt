	最近的一个WAR包是可以直接放到Tomcat运行的，数据存在阿里云上。
大家准备答辩的时候可以很容易的在本地运行我们的项目，但是我们的数据
是公用的，请大家使用时注意。如果有什么使用问题可以私聊我。


后台
	Account		admin
	password 	admin


DataBase
	Address 	score.kyle.ren
	User		score
	Password	Jtu9Aj2CrMBqE5nKpb43l7wLFmyf6aeQ
